#ifndef UTILITIES_INCLUDED
#define UTILITIES_INCLUDED


#include <iostream>
#include <string>
#include <cctype>

using namespace std;

void lowerInput(string& s);








#endif